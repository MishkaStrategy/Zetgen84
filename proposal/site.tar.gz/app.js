(() => {
  document.documentElement.classList.add('js');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const progress = () => {
    const max = Math.max(document.documentElement.scrollHeight - innerHeight, 1);
    document.documentElement.style.setProperty('--progress', Math.min(1, Math.max(0, scrollY / max)).toFixed(4));
  };
  addEventListener('scroll', progress, {passive:true});
  progress();

  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-in');
        revealObserver.unobserve(entry.target);
      }
    });
  }, {threshold:.08, rootMargin:'0px 0px -6% 0px'});
  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

  const links = [...document.querySelectorAll('.topbar__nav a')];
  const sections = [...document.querySelectorAll('main section[id]')];
  const navObserver = new IntersectionObserver(entries => {
    const current = entries.filter(e => e.isIntersecting).sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!current) return;
    links.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${current.target.id}`));
  }, {threshold:[.2,.45,.7], rootMargin:'-20% 0px -55% 0px'});
  sections.forEach(section => navObserver.observe(section));

  document.querySelectorAll('[data-horizontal]').forEach(shell => {
    shell.addEventListener('wheel', e => {
      if (innerWidth < 760 || Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
      const max = shell.scrollWidth - shell.clientWidth;
      if (max <= 0) return;
      const atStart = shell.scrollLeft <= 0 && e.deltaY < 0;
      const atEnd = shell.scrollLeft >= max - 2 && e.deltaY > 0;
      if (atStart || atEnd) return;
      e.preventDefault();
      shell.scrollLeft += e.deltaY * .8;
    }, {passive:false});
  });

  const scene = document.getElementById('jarScene');
  const frame = scene?.closest('.art-frame');
  if (scene && frame && !reduce && matchMedia('(pointer:fine)').matches) {
    frame.addEventListener('pointermove', e => {
      const r = frame.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width - .5) * 12;
      const y = ((e.clientY - r.top) / r.height - .5) * -8;
      scene.style.transform = `translate(-50%,-50%) rotateX(${y}deg) rotateY(${x}deg)`;
    }, {passive:true});
    frame.addEventListener('pointerleave', () => scene.style.transform = 'translate(-50%,-50%) rotateX(2deg)');
  }

  // Runner-only deterministic screenshots. Isolate the requested section rather than relying on long-page hash scrolling.
  const params = new URLSearchParams(location.search);
  if (params.get('qa') === '1' && location.hash) {
    const target = document.querySelector(location.hash);
    if (target) {
      document.querySelectorAll('main > section').forEach(section => {
        if (section !== target) section.style.display = 'none';
      });
      document.querySelector('.topbar')?.remove();
      document.querySelector('.scroll-progress')?.remove();
      target.style.minHeight = '100vh';
      target.style.paddingTop = '70px';
      target.querySelectorAll('.reveal').forEach(el => el.classList.add('is-in'));
      scrollTo(0, 0);
    }
  }
})();
